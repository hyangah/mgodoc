#include <dlfcn.h>

int main(int argc, char** argv) {
  if (!dlopen(argv[1], RTLD_LAZY|RTLD_GLOBAL)) {
	printf("android_test_harness: dlopen %s failed\n", argv[1]);
	return 1;
  }
  int (*_rt0_arm_linux1) (int argc, char** argv);
  if (!_rt0_arm_linux1) {
	printf("android_test_harness: %s missing _rt0_arm_linux1", argv[1]);
	return 1;
  }
  _rt0_arm_linux1(argc, x.argv);
  return 0;
}
